import * as React from "react";
import type { SVGProps } from "react";
const Home = (props: SVGProps<SVGSVGElement>) => (
  <svg
    width={38}
    height={38}
    viewBox="0 0 38 38"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M9.71115 33.25C7.84566 33.25 6.33337 31.6976 6.33337 29.7826V15.8457C6.33337 14.7924 6.79981 13.7962 7.60107 13.1381L16.89 5.50982C18.1236 4.49673 19.8765 4.49673 21.1101 5.50982L30.399 13.1381C31.2003 13.7962 31.6667 14.7924 31.6667 15.8457V29.7826C31.6667 31.6976 30.1544 33.25 28.2889 33.25H9.71115Z"
      stroke="black"
      strokeWidth={2.625}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M15.0416 33.25V24.5417C15.0416 22.7928 16.4594 21.375 18.2083 21.375H19.7916C21.5405 21.375 22.9583 22.7928 22.9583 24.5417V33.25"
      stroke="black"
      strokeWidth={2.625}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
export { Home };
